package com.example.oxidephantom

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(17, 16, 25))
        }
        val title = TextView(this).apply {
            text = "OXIDE PHANTOM"
            textSize = 26f
            setTextColor(Color.rgb(198, 154, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "ARM64 • FLOATING UI DEMO"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        val start = Button(this).apply {
            text = "Разрешить отображение поверх окон"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, FloatingMenuService::class.java))
                    finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "Демонстрационная панель интерфейса. Она не подключается к памяти игры, не меняет игровой процесс и не содержит работающего aimbot/ESP."
            textSize = 13f
            setTextColor(Color.rgb(190, 180, 205))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(start)
        layout.addView(note)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            // User can tap the button again to launch the panel.
        }
    }
}
