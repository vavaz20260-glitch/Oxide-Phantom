package com.example.oxidephantom

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast

class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val purple = Color.rgb(190, 130, 255)
    private val bg = Color.rgb(20, 17, 29)
    private val card = Color.rgb(39, 29, 55)
    private val textColor = Color.rgb(244, 238, 255)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
    }

    private fun label(value: String, size: Float = 14f): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(textColor)
            setPadding(14, 10, 14, 10)
        }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "P"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(111, 58, 164))
            setOnClickListener { togglePanel() }
        }
        bubble = b
        val p = params(54, 54).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        wm.addView(b, p)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x=ox+(e.rawX-sx).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(v, lp); return true }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) togglePanel(); return true }
                }
                return false
            }
        })
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel)
            panel = null
        } else showPanel()
    }

    private fun showPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(label("OXIDE PHANTOM", 18f), LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("✕").apply {
                setTextColor(purple)
                setOnClickListener { togglePanel() }
            })
        }
        outer.addView(header)
        outer.addView(label("SURVIVAL ISLAND  •  UI DEMO", 10f).apply { setTextColor(purple) })

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun section(name: String) {
            content.addView(label(name).apply {
                setTextColor(purple); setTypeface(null, Typeface.BOLD)
                setBackgroundColor(card)
            })
        }
        fun row(name: String, description: String) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(4, 5, 4, 5)
                addView(label(name))
                addView(label(description, 10f).apply { setTextColor(Color.LTGRAY) })
            }
            content.addView(item)
        }
        fun tab(name: String, entries: List<Pair<String, String>>) {
            section(name)
            entries.forEach { row(it.first, it.second) }
        }

        tab("AIMBOT", listOf(
            "Aim Assist Preview" to "Только демонстрация интерфейса",
            "FOV Circle" to "Визуальный макет круга",
            "Target Indicator" to "Демо-индикатор цели",
            "Smoothness" to "Макет настройки плавности"
        ))
        tab("VISUALS", listOf(
            "Player Boxes Preview" to "Демонстрационные рамки",
            "Name Tags Preview" to "Макет подписей",
            "Distance Display" to "Макет дистанции",
            "Skeleton Preview" to "Демонстрационный скелет",
            "Crosshair" to "Настройка вида прицела"
        ))
        tab("RADAR", listOf(
            "Radar Preview" to "Декоративная тестовая мини-карта",
            "Marker Style" to "Настройка вида маркеров"
        ))
        tab("MISC", listOf(
            "FPS Counter" to "Показывает частоту обновления UI",
            "Custom HUD" to "Настройка макета HUD",
            "Save Config" to "Настройки сохраняются в будущей версии"
        ))

        outer.addView(label("Это UI-макет: нет чтения памяти игры или управления прицелом.", 10f)
            .apply { setTextColor(Color.rgb(190, 165, 215)) })
        panel = outer
        wm.addView(outer, params(300, 520))
    }

    override fun onDestroy() {
        bubble?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        panel?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        bubble = null; panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
